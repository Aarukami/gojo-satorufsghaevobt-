from kurama9tAnimeBot import DEV_USERS

SUDOERS = DEV_USERS

