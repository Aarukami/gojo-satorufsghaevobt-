# This File Contains all the Picture Links used all over the Bot

#Images in __main__.py
KURAMA9T_IMG = "https://telegra.ph/file/fb9fd30fcd2d32e723e45.jpg"
KURAMA9T_START_IMG = "https://telegra.ph/file/7a43a8cc386df62f176eb.jpg"
KURAMA9T_IMG = "https://telegra.ph/file/65fb4fdec1bd9787f01a0.jpg"