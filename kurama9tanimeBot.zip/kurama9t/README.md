![Gojo](https://telegra.ph/file/7d58dac2c760e2d63c7b4.jpg)
# Gojo
[![Maintenance](https://img.shields.io/badge/Maintained%3F-yes-green.svg)](https://github.com/IzumiCypherX/EmiliaAnimeBot/graphs/commit-activity) [![GPLv3 license](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://perso.crans.org/besson/LICENSE.html)<br> [![Open Source Love svg2](https://badges.frapsoft.com/os/v2/open-source.svg?v=103)](https://github.com/ellerbrock/open-source-badges/) [![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](https://makeapullrequest.com)<br> [![Updates channel!](https://img.shields.io/badge/Join%20Channel-↗️-red)](https://t.me/mhaprvt) 
[![Support Group!](https://img.shields.io/badge/Join%20Group-↗️-green)](https://t.me/mhaprvt)


> If There's no Trace of This Repo in your Bot, We will be pushing a gban on you from our systems.


### Can be found on telegram as [Gojo](https://t.me/I_Am_Strongest_bot).

##### For Session String, Run stringgen.py locally

### Status

+ [x] Maintained
+ [x] Support Group Included
+ [x] Free
+ [x] OpenSourced
+ [x] Working Instance Available
+ [x] Clean Code
+ [x] Heroku Deploy
+ [x] Docker/Local Machine

#### Creator Info/Credits

Thanks To:
> @Aarukami
> @shvvvvvvvv1



The Support group can be reached out to at [mhapvt](https://t.me/mhaprvt), where you can ask for help about [Gojo](https://t.me/I_Am_Strongest_bot), discover/request new features, report bugs, and stay in the loop whenever a new update is available. 

<details>
  <summary>Heroku Deploy</summary>
  <br>
  <b>
The Easiest Way to Deploy This Bot is Via Heroku.
    In Order To deploy, You Just Have Fill The Necessary Environment Variables and Done!</b>
  
  <h1>
    <p align="center">
        <a href="https://heroku.com/deploy?template=https://github.com/Aarukami/gojo-satoru">
            <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy">
        </a>
    </p>
</h1>

</details> 

<details>
    <summary>More Deploy Options</summary>
    <br>
    <p align="center">

    Deploying on Local Machine

</p>

console
    IzumiCypherx@arch:~$ git clone https://github.com/Aarukami/gojo-satoru
    IzumiCypherx@arch:~$ cd kurama9tAnimeBot
    IzumiCypherx@arch:~$ cp sample_config.py config.py

Edit Config.py with your own Values

Start with python -m kurama9tAnimeBot 

</details>    

<details>
     <summary>Deploying On IDE VMs Like Repl.it</summary>
       <br>
         <p align="left">
            <b> 

            Refer to Deploying On Local Machine

 </b>
</p>
</details>